load("common.js");

function execute(input, page) {
    var prefix = sitePath(input);
    if (prefix !== "/" && prefix.indexOf("/tags/") !== 0) return Response.error("Danh mục không hợp lệ.");
    var path = sitePath(page) || prefix;
    if (path.indexOf(prefix) !== 0) return Response.error("Trang danh mục không hợp lệ.");
    var doc = getPage(path);
    if (!doc) return Response.error("Không mở được danh mục Novel543.");
    var books = booksFrom(doc);
    if (!books.length) return Response.error("Novel543 không trả về danh sách truyện.");
    var next = prefix === "/" ? null : nextListing(doc, prefix);
    return Response.success(books, next === path ? null : next);
}
