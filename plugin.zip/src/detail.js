load("common.js");

function execute(url) {
    var path = bookPath(url);
    if (!path) return Response.error("Đường dẫn truyện Novel543 không hợp lệ.");
    var doc = getPage(path);
    if (!doc) return Response.error("Không mở được trang truyện Novel543.");
    var title = doc.select("#detail h1, h1").first();
    if (!title || !title.text().trim()) return Response.error("Không tìm thấy tên truyện.");
    var cover = doc.select("#detail .cover img");
    var author = doc.select("#detail .author").text().replace(/^作者\s*[:：/]\s*/, "");
    return Response.success({
        name: title.text().trim(),
        author: author,
        cover: coverUrl(cover.attr("data-src") || cover.attr("data-original") || cover.attr("src")),
        description: doc.select("#detail .intro").text(),
        detail: doc.select("#detail p.meta").text(),
        host: BASE,
        ongoing: !/已完結|已完结/.test(doc.select("#detail p.meta").text())
    });
}
