load("common.js");

function chapterKey(path) {
    var match = path.match(/^(\/\d+\/\d+_\d+)(?:_\d+)?\.html$/);
    return match ? match[1] : "";
}

function execute(url) {
    var path = sitePath(url);
    var key = chapterKey(path);
    if (!key) return Response.error("Đường dẫn chương Novel543 không hợp lệ.");
    var visited = {};
    var pages = [];
    while (path && !visited[path] && pages.length < 20) {
        visited[path] = true;
        var doc = getPage(path);
        if (!doc) return Response.error("Không mở được trang chương Novel543.");
        var element = doc.select("div.chapter-content div.content, #chapterWarp .novel-reader-content, #chapterWarp .article-content").first();
        if (!element) return Response.error("Không tìm thấy nội dung chương Novel543.");
        element.select("script, style, iframe, noscript, .gadBlock, .adBlock, [id*=tam-ad]").remove();
        pages.push(element.html().replace(/<(\/?)(p|br|div|b|i|strong|em)(?=[\s/>])[^>]*>|<[^>]+>/gi,
            function (tag, close, name) { return name ? "<" + close + name.toLowerCase() + ">" : ""; }));
        var next = "";
        doc.select("a[href]").forEach(function (anchor) {
            var href = anchor.attr("href");
            var candidate = /^\d+(?:_\d+)+\.html$/.test(href) ? path.replace(/[^/]+$/, "") + href : sitePath(href);
            if (!next && chapterKey(candidate) === key && !visited[candidate] &&
                (anchor.attr("rel") === "next" || /^(下[一1][頁页章]|下一[頁页章][>›»])$/.test(anchor.text().replace(/\s+/g, "")))) {
                next = candidate;
            }
        });
        path = next;
    }
    return path ? Response.error("Chương có quá nhiều trang.") : Response.success(pages.join("<br>"));
}
