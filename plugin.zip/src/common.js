var BASE = "https://www.novel543.com";

function sitePath(value) {
    var path = String(value || "").replace(/^(?:https?:)?\/\/(?:www\.)?novel543\.com(?=\/|$)/i, "");
    return /^\/(?!\/)/.test(path) ? path.split("#")[0] : "";
}

function bookPath(value) {
    var match = sitePath(value).match(/^(\/\d+)(?:\/?|\/dir\/?)?(?:\?.*)?$/);
    return match ? match[1] + "/" : "";
}

function coverUrl(value) {
    var cover = String(value || "");
    if (cover.indexOf("//") === 0) return "https:" + cover;
    if (cover.indexOf("/") === 0) return BASE + cover;
    return /^https?:\/\//i.test(cover) ? cover : "";
}

function getPage(path) {
    var response = fetch(BASE + path);
    return response.ok ? response.html() : null;
}

function booksFrom(doc) {
    var books = [];
    var byPath = {};
    doc.select("a[href]").forEach(function (anchor) {
        var path = bookPath(anchor.attr("href"));
        if (!path) return;
        var image = anchor.select("img");
        var name = anchor.text().trim() || anchor.attr("title").trim() || image.attr("alt").trim();
        var cover = coverUrl(image.attr("data-src") || image.attr("data-original") || image.attr("src"));
        if (!byPath[path]) byPath[path] = {link: BASE + path, host: BASE};
        if (name && !byPath[path].name && !/^(閱讀|閱讀全文|開始閱讀|立即閱讀|目錄|章節列表)$/.test(name)) {
            byPath[path].name = name;
            books.push(byPath[path]);
        }
        if (cover && !byPath[path].cover) byPath[path].cover = cover;
    });
    return books;
}

function nextListing(doc, prefix) {
    var next = "";
    doc.select("a[href]").forEach(function (anchor) {
        var path = sitePath(anchor.attr("href"));
        if (!next && path.indexOf(prefix) === 0 &&
            (anchor.attr("rel") === "next" || /^下一[頁页]$/.test(anchor.text().trim()))) next = path;
    });
    return next || null;
}
