load("common.js");

function execute(key, page) {
    key = String(key || "").trim();
    if (!key) return Response.success([]);
    var direct = bookPath(key);
    if (direct) {
        var book = getPage(direct);
        var title = book && book.select("#detail h1, h1").first();
        if (title) return Response.success([{name: title.text(), link: BASE + direct, host: BASE}]);
        return Response.error("Không mở được truyện từ đường dẫn Novel543.");
    }
    var prefix = "/search/" + encodeURIComponent(key);
    var path = sitePath(page) || prefix;
    if (path.indexOf(prefix) !== 0) return Response.error("Trang tìm kiếm không hợp lệ.");
    var doc = getPage(path);
    if (!doc) return Response.error("Novel543 không trả về trang tìm kiếm. Thử mở một danh mục hoặc dán URL truyện.");
    var next = nextListing(doc, prefix);
    return Response.success(booksFrom(doc), next === path ? null : next);
}
