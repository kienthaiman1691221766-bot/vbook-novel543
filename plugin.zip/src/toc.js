load("common.js");

function execute(url) {
    var path = bookPath(url);
    if (!path) return Response.error("Đường dẫn mục lục Novel543 không hợp lệ.");
    var doc = getPage(path + "dir");
    if (!doc) return Response.error("Không mở được mục lục Novel543.");
    var chapters = [];
    var seen = {};
    doc.select("div.chaplist ul.all a[href]").forEach(function (anchor) {
        var href = anchor.attr("href");
        var chapter = /^\d+(?:_\d+)+\.html$/.test(href) ? path + href : sitePath(href);
        if (chapter.indexOf(path) !== 0 ||
            !/\/\d+(?:_\d+)+\.html$/.test(chapter) || seen[chapter]) return;
        var name = anchor.text().trim();
        if (!name) return;
        seen[chapter] = true;
        chapters.push({name: name, url: BASE + chapter, host: BASE});
    });
    return chapters.length ? Response.success(chapters) : Response.error("Không tìm thấy chương trong mục lục Novel543.");
}
