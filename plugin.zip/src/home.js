function execute() {
    return Response.success([
        {title: "Đề xuất và truyện mới", input: "/", script: "list.js"},
        {title: "Xuyên không", input: "/tags/" + encodeURIComponent("穿越") + "/", script: "list.js"},
        {title: "Đô thị", input: "/tags/" + encodeURIComponent("都市") + "/", script: "list.js"},
        {title: "Huyền ảo", input: "/tags/" + encodeURIComponent("玄幻") + "/", script: "list.js"},
        {title: "Lịch sử", input: "/tags/" + encodeURIComponent("歷史") + "/", script: "list.js"}
    ]);
}
